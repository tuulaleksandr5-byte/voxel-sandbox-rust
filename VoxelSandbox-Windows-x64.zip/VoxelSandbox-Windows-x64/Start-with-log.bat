@echo off
cd /d "%~dp0"
set RUST_LOG=info
start "Voxel Sandbox" /wait /b VoxelSandbox.exe > voxel-log.txt 2>&1
echo Exit code: %errorlevel%>>voxel-log.txt
