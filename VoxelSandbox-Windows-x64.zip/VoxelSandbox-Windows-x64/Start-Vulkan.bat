@echo off
cd /d "%~dp0"
set WGPU_BACKEND=vulkan
start "Voxel Sandbox" VoxelSandbox.exe
