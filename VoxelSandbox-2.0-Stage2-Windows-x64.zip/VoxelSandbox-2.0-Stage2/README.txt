﻿Voxel Sandbox 2.0 Survival — альфа, этап 2 из 8

Распакуйте весь архив и запустите VoxelSandbox.exe.
Текстуры, шрифт, звуки и значок встроены в EXE.
assets/data/survival.ron — редактируемый баланс с обновлением без перезапуска.

Добавлены Survival/Creative, здоровье, голод, воздух, смерть и возрождение.
Нажмите / для консоли; Enter выполняет команду, Esc закрывает.
/gamemode creative
/gamemode survival
/gamerule keepInventory true
/gamerule naturalRegeneration false
Полёт: дважды Space (Creative); Space вверх, Shift вниз; Ctrl ускорение.

Миры по умолчанию в saves-v2/. Исходный каталог saves/ Foundation не затрагивается.
Постройки, seed и позиция сохраняются; новые статы, режим и правила пока сбрасываются при загрузке (полное хранение — этап 8).
Бесконечные блоки и мгновенная добыча пока сохранены до этапов 3–4. Дропа, крафта, руд и инструментов ещё нет.

Проверено: 112 Linux-тестов, 80 Windows-тестов через Wine; запуск Linux/Xvfb и Windows EXE/Wine/Vulkan. Настоящая Windows-машина не проверена.
Новая прямая зависимость: game_core → ron 0.12.3. Версии существующих библиотек не менялись.

Полные новые файлы и diff: stage-1-2.patch.
Исходники: https://github.com/tuulaleksandr5-byte/voxel-sandbox-rust/tree/f464a9c1cd27956561aa8c948e73d43f66bdbe68
План и полный отчёт: docs/SURVIVAL_V2_PLAN.md, docs/STAGE_2_SURVIVAL.md в исходниках.
